/*@charset "gb2312";*/

if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
   //alert(navigator.userAgent); 
   
   //add a new meta node of viewport in head node
	head = document.getElementsByTagName('head');
	viewport = document.createElement('meta');
	viewport.name = 'viewport';
	viewport.content = 'target-densitydpi=device-dpi, width=' + 640 + 'px, user-scalable=no';
	head.length > 0 && head[head.length - 1].appendChild(viewport);    
   
}
	
$(function(){
	 var wechat_developer_reload = function(){
		$('body').append('<input type="button" value="refresh" onclick="window.location.reload();"/>');	 
	} 
	//wechat_developer_reload();
	
	if (window.console) {
		console.info(">>Join us? Email：developer@qietu.com");
	}		
	
	//页面不足一屏，铺满一屏
	$('.layout').css('min-height',$(window).height());
	
	$('.fx').click(function(){
			if($('.share').hasClass('on')){
				$('.share').slideUp();
				$('.share').removeClass('on');
				}else{
					$('.share').slideDown();
					$('.share').addClass('on');
					}
		})
		
	$('.a5_1').click(function(){
			if($('.tc').hasClass('on')){
				$('.tc').slideUp();
				$('.tc').removeClass('on');
				}else{
					$('.tc').slideDown();
					$('.tc').addClass('on');
					}
		})
	
	

	
	$('.footnav li,.hdxq .nav li,.wzxq .nav li,.pl .list li .info dd a').click(function(){
		$(this).addClass('selected');		
	})
	$('.footnav .a5').click(function(){
		
		if($('.tc').is(':visible')){
			$('.tc').hide();
			$(this).parent().removeClass('selected');
		}	
		else{
			$('.tc').show();
			$(this).parent().addClass('selected');
		}
		return false;
	}) 
	$('.sharejs').click(function(){
		if($('.share').is(':visible')){
			$('.share').hide();
			$(this).removeClass('selected');
		}	
		else{
			$('.share').show();
			$(this).addClass('selected');
		}
		return false;
	})
	
	var synavli = $('.sy-nav li');
	$('.sy-nav ul').css('width',synavli.size()*(synavli.width()+40));
	
	var syactivityli = $('.sy .hd-list li');
	$('.sy .hd-list ul').css('width',syactivityli.size()*(syactivityli.width()+40));
	
	
	var sybannerli = $('.sy .sy-imgs li');
	$('.sy .sy-imgs ul').css('width',sybannerli.size()*(sybannerli.width()+20));
	
	var syactivityli = $('.sy .activity .body li');
	$('.sy .activity .body ul').css('width',syactivityli.size()*(syactivityli.width()+34));
	
	$('.list .tags .btn').click(function(){
		if($('.list .tags').hasClass('selected')){
			$('.list .tags').removeClass('selected');
		}
		else{
			$('.list .tags').addClass('selected');
		}
		
		return false;
	})
	$('.sy-nav li a').click(function(){
		$(this).parent().addClass('on');
	})
	//文章列表页面
	$('.article-new .tags .btn').click(function(){
		if($('.article-new .tags').hasClass('selected')){
			$('.article-new .tags').removeClass('selected');
		}
		else{
			$('.article-new .tags').addClass('selected');
		}
		
		return false;
	})
	
	/*-----频道专家 表单元素 下拉菜单---*/
	$('.selectr select').change(function(){
		$(this).parent().find('strong').html($(this).val());
		
	})
	/*-----文章详情 展开---*/
	$('.wzxq .card .body em').click(function(){
		if($(this).parent().hasClass('selected')){
			$(this).parent().removeClass('selected');
		}else{
			$(this).parent().addClass('selected');
		}
		
	})
	
	//幻灯片
	if($('.wz-banner').size()>0 || $('.sy-banner').size()>0){
		var glide = $('.wz-banner,.sy-banner').glide({

			//autoplay:true,//是否自动播放 默认值 true如果不需要就设置此值

			animationTime:500, //动画过度效果，只有当浏览器支持CSS3的时候生效

			arrows:false, //是否显示左右导航器
			//arrowsWrapperClass: "arrowsWrapper",//滑块箭头导航器外部DIV类名
			//arrowMainClass: "slider-arrow",//滑块箭头公共类名
			//arrowRightClass:"slider-arrow--right",//滑块右箭头类名
			//arrowLeftClass:"slider-arrow--left",//滑块左箭头类名
			arrowRightText:"",//定义左右导航器文字或者符号也可以是类
			arrowLeftText:"",

			nav:true, //主导航器也就是本例中显示的小方块
			navCenter:true, //主导航器位置是否居中
			navClass:"slider-nav",//主导航器外部div类名
			navItemClass:"slider-nav__item", //本例中小方块的样式
			navCurrentItemClass:"slider-nav__item--current" //被选中后的样式
		});
	}
	//专家榜 下拉菜单
	$('.nav-select li h2').click(function(){	
		if($(this).parent().hasClass('selected')){
			$(this).parent().removeClass('selected');
			return false;
		}else{
			$(this).parent().parent().find('li').removeClass('selected');
			$(this).parent().addClass('selected');
			
			return false;
		}
	})
	$('body').click(function(event){
		
		var n = $(event.target).parent()[0].className;
		if(n=='mask-select'){
			$(event.target).addClass('selected');			
			$(event.target).parent().parent().find('h2').html($(event.target).html());
			$(event.target).parent().parent().removeClass('selected');			
			$(event.target).parent().parent().parent().find('dd').removeClass('selected');
			$(event.target).addClass('selected');
		}else{
			$('.nav-select li').removeClass('selected');
		}
		return false;
	})
	
	//个人主页 取消 关注
	$('.grzy .card .btn a').click(function(){
		if($(this).parent().hasClass('qx')){
			$(this).parent().removeClass('qx');
			return false;
			
		}else{
			$(this).parent().addClass('qx');
			return false;	
		}
	})
	//个人主页 想咨询
	$('.grzy .foot .a1').click(function(){
		$(this).addClass('selected');
		return false;
		
	})
	$('.grzy .zx-foot .a1').click(function(){
		$(this).parent().addClass('on');
		return false;
	})
	//首页弹窗
	$('.sy-new-nav li .more').click(function(){
		$('.dialog').css('display','block');
		return false;
	})
	$('.dialog .close').click(function(){
		$(this).parent().parent().css('display','none');
	})
	
//	个人主页-专家
	$('.info-nav li').click(function(){
		$('.info-nav li').removeClass('selected').eq($(this).index()).addClass('selected');
		$('.info-tab').hide().eq($(this).index()).show();
		
		return false;
	})
	//	我的收藏
	$('.info-nav dd').click(function(){
		$('.info-nav dd').removeClass('selected').eq($(this).index()).addClass('selected');
		$('.info-tab').hide().eq($(this).index()).show();
		
		return false;
	})
	
	//底部菜单
//	var p=0,t=0;
//
//	$(window).scroll(function(e){
//			p = $(this).scrollTop();
//			
//			if(t<=p){
//				$('.wzxq .nav,.grzy .foot,.grzy .zx-foot').addClass('hide');
//			}
//
//			else{
//				$('.wzxq .nav,.grzy .foot,.grzy .zx-foot').removeClass('hide');
//				
//			}
//			setTimeout(function(){t = p;},0);		
//	});

})

